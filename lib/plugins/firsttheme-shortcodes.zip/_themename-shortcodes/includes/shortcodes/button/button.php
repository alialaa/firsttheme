<?php

function firsttheme_button($atts = [], $content = null, $tag = '') {
    extract(shortcode_atts([
        'color' => 'red',
        'text' => 'Button'
    ], $atts, $tag));
    
    return '<button class="firsttheme_button" style="background-color: ' . esc_attr($color) . '">' . do_shortcode($content) . '</button>';
}
add_shortcode('firsttheme_button', 'firsttheme_button');