<?php
/*
Plugin Name:  firsttheme shortcodes
Plugin URI:   
Description:  Adding Shortcodes for firsttheme
Version:      1.0.0
Author:       Ali Alaa
Author URI:   http://alialaa.com/
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  firsttheme-shortcodes
Domain Path:  /languages
*/

if( !defined('WPINC')) {
    die;
}

function firsttheme_shortcodes_init() {
    include_once('includes/shortcodes/button/button.php');
}

add_action('init', 'firsttheme_shortcodes_init');

include_once('includes/enqueue-assets.php');