<?php

function firsttheme_shortcodes_scripts( ) {
    wp_enqueue_script( 'firsttheme-shortcodes-scripts', plugins_url( 'firsttheme-shortcodes/dist/assets/js/bundle.js' ), array( 'jquery' ), '1.0.0', true);

    wp_enqueue_style( 'firsttheme-shortcodes-stylesheet',  plugins_url('firsttheme-shortcodes/dist/assets/css/bundle.css'), array(), '1.0.0', 'all' );
}
add_action( 'wp_enqueue_scripts', 'firsttheme_shortcodes_scripts' );